var l=Object.defineProperty;var f=(n,t,e)=>t in n?l(n,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):n[t]=e;var c=(n,t,e)=>f(n,typeof t!="symbol"?t+"":t,e);class a{constructor(){c(this,"url",window.location.href);c(this,"doc",document)}findCA(t){const e=/0x[a-fA-F0-9]{40}/,r=t.match(e);return r?r[0].toLowerCase():void 0}distillCommonText(){const t=[],e=Array.from(this.doc.querySelectorAll("h1, h2, p, span.address"));for(const r of e.slice(0,10)){const o=r.innerText.trim();o.length>10&&t.push(o.substring(0,200))}return t}}class m extends a{extract(){var r;const t=this.findCA(this.url),e=(r=this.doc.querySelector("h1"))==null?void 0:r.innerText;return{sourcePlatform:"fourmeme",contractAddress:t,tokenName:e,confidence:t?1:.6,detectionReason:t?"Resolved CA from Four.Meme URL":"Four.Meme context detected"}}}class u extends a{extract(){var o;const t=this.findCA(this.url),e=(o=this.doc.querySelector('div[data-testid="token-address"]'))==null?void 0:o.innerText,r=e?this.findCA(e):void 0;return{sourcePlatform:"dexscreener",contractAddress:t||r,confidence:t||r?1:.5,detectionReason:t?"Resolved CA from DexScreener pair URL":r?"Resolved CA from DexScreener badge":"DexScreener context detected"}}}class p extends a{extract(){const t=Array.from(this.doc.querySelectorAll('[data-testid="tweetText"]'));let e;const r=[];for(const o of t){const i=o.innerText;r.push(i.substring(0,200)),e||(e=this.findCA(i))}return{sourcePlatform:"twitter",contractAddress:e,extractedText:r,confidence:e?.8:.3,detectionReason:e?"Extracted CA from Twitter thread":"Twitter context detected"}}}class x extends a{extract(){const t=Array.from(this.doc.querySelectorAll(".message, .text-content"));let e;const r=[];for(const o of t){const i=o.innerText;r.push(i.substring(0,200)),e||(e=this.findCA(i))}return{sourcePlatform:"telegram",contractAddress:e,extractedText:r,confidence:e?.8:.3,detectionReason:e?"Extracted CA from Telegram message":"Telegram context detected"}}}class b extends a{extract(){const t=this.findCA(this.url)||this.findCA(this.doc.body.innerText);return{sourcePlatform:"generic",contractAddress:t,confidence:t?.7:.2,detectionReason:t?"Contract found via generic text scan":"Awaiting operative target"}}}function g(){const n=window.location.href;let t;n.includes("four.meme")?t=new m:n.includes("dexscreener.com")?t=new u:n.includes("x.com")||n.includes("twitter.com")?t=new p:n.includes("web.telegram.org")?t=new x:t=new b;const e=t.extract(),r=t.distillCommonText();return{sourcePlatform:e.sourcePlatform||"generic",pageUrl:n,pageTitle:document.title,contractAddress:e.contractAddress,fourMemeUrl:e.fourMemeUrl,dexscreenerUrl:e.dexscreenerUrl,tokenName:e.tokenName,tokenTicker:e.tokenTicker,extractedText:e.extractedText||r,confidence:e.confidence||0,detectionReason:e.detectionReason||"Contextual analysis"}}chrome.runtime.onMessage.addListener((n,t,e)=>{if(n.action==="EXTRACT_TOKEN"){console.log("[Sentinel_AI] Initiating platform-aware intelligence scan..."),s();const r=g();e(r)}return n.action==="SHOW_VOICE_HUD"&&(console.log("[Sentinel_AI] Manual HUD trigger:",n.status||"WAITING"),d(n.status||"WAITING"),e&&e({success:!0})),n.action==="SHOW_PERMISSION_ERROR"&&(E(),e({success:!0})),n.action==="HIDE_VOICE_HUD"&&(s(),e({success:!0})),!0});function h(){if(document.getElementById("sentinel-pinned-orb"))return;const n=document.createElement("div");n.id="sentinel-pinned-orb",Object.assign(n.style,{position:"fixed",bottom:"20px",right:"20px",width:"48px",height:"48px",zIndex:"2147483647",background:"rgba(0, 0, 0, 0.8)",border:"2px solid rgba(0, 248, 187, 0.3)",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",transition:"all 0.5s cubic-bezier(0.4, 0, 0.2, 1)",boxShadow:"0 0 20px rgba(0, 248, 187, 0.1)",backdropFilter:"blur(10px)"}),n.innerHTML=`
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#00f8bb" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
    </svg>
    <style>
      @keyframes breathing-glow {
        0%, 100% { box-shadow: 0 0 20px rgba(0, 248, 187, 0.2); border-color: rgba(0, 248, 187, 0.3); transform: scale(1); }
        50% { box-shadow: 0 0 40px rgba(0, 248, 187, 0.6); border-color: rgba(0, 248, 187, 0.8); transform: scale(1.1); }
      }
      @keyframes listening-pulse {
        0%, 100% { box-shadow: 0 0 15px #00e0ff; transform: scale(1); border-color: #00e0ff; }
        50% { box-shadow: 0 0 35px #00e0ff; transform: scale(1.15); border-color: #fff; }
      }
      @keyframes speaking-wave {
        0% { transform: scale(1); box-shadow: 0 0 20px #00f8bb; }
        25% { transform: scale(1.1) rotate(5deg); }
        50% { transform: scale(1.05) rotate(-5deg); }
        100% { transform: scale(1); box-shadow: 0 0 40px #00f8bb; }
      }
      @keyframes fast-pulse {
        0%, 100% { box-shadow: 0 0 10px #00f8bb; transform: scale(1); }
        50% { box-shadow: 0 0 30px #00f8bb; transform: scale(1.2); }
      }
      .sentinel-listening-mode {
        animation: listening-pulse 1.5s ease-in-out infinite !important;
        background: rgba(0, 224, 255, 0.2) !important;
      }
      .sentinel-speaking-mode {
        animation: speaking-wave 0.8s ease-in-out infinite !important;
        background: rgba(0, 248, 187, 0.2) !important;
      }
      .sentinel-processing {
        animation: fast-pulse 0.5s infinite !important;
        border-color: #00f8bb !important;
      }
      @keyframes hud-pulse {
        0%, 100% { opacity: 1; transform: scale(1); box-shadow: 0 0 10px #00f8bb; }
        50% { opacity: 0.5; transform: scale(1.2); box-shadow: 0 0 20px #00f8bb; }
      }
    </style>
  `,n.onclick=()=>{console.log("[Sentinel_AI] Manual trigger requested via Orb click."),chrome.runtime.sendMessage({action:"TRIGGER_COMMAND_LISTENING"}),d("LISTENING")},document.body.appendChild(n)}function d(n="WAITING"){s();const t=document.getElementById("sentinel-pinned-orb");t&&(t.className="",n==="LISTENING"?t.classList.add("sentinel-listening-mode"):n==="SPEAKING"||n==="GREETING"?t.classList.add("sentinel-speaking-mode"):n==="ANALYZING"&&t.classList.add("sentinel-processing"));const e=document.createElement("div");e.id="sentinel-voice-hud",Object.assign(e.style,{position:"fixed",top:"20px",left:"50%",transform:"translateX(-50%)",zIndex:"2147483647",padding:"12px 24px",background:"rgba(0, 0, 0, 0.9)",border:"2px solid #00f8bb",borderRadius:"8px",color:"#00f8bb",fontFamily:'"Orbitron", "Inter", sans-serif',fontSize:"12px",fontWeight:"900",textTransform:"uppercase",letterSpacing:"0.2em",display:"flex",alignItems:"center",gap:"12px",pointerEvents:"none",boxShadow:"0 0 30px rgba(0, 248, 187, 0.3)",transition:"all 0.3s ease"});let r="",o=5e3;switch(n){case"GREETING":r='<span style="animation: hud-pulse 1s infinite;">🎙️</span> INITIALIZING SENTINEL...',o=0;break;case"LISTENING":e.style.borderColor="#00e0ff",e.style.color="#00e0ff",r="<span>🔵</span> LISTENING FOR COMMAND...";break;case"HEARING":r="<span>🟢</span> COMMAND RECEIVED...";break;case"ANALYZING":r='<span style="animation: hud-pulse 1s infinite;">🛰️</span> ANALYZING OPERATIVE TARGET...';break;case"SPEAKING":e.style.boxShadow="0 0 40px rgba(0, 248, 187, 0.6)",r='<span style="animation: hud-pulse 0.5s infinite;">🔊</span> SENTINEL DELIVERY IN PROGRESS...',o=0;break;case"IDLE":return;case"SUCCESS":r="<span>✅</span> ANALYSIS COMPLETE",o=3e3;break;case"NOT_FOUND":r="<span>⚠️</span> SCAN FAILED: NO CONTRACT DETECTED",e.style.borderColor="#ff4444",e.style.color="#ff4444",o=4e3;break;case"ERROR":r="<span>❌</span> OPERATIVE ERROR: RETRY COMMAND",e.style.borderColor="#ff4444",e.style.color="#ff4444",o=4e3;break;default:r='<span style="width: 10px; height: 10px; background: #00f8bb; border-radius: 50%; animation: hud-pulse 1s infinite;"></span> SEARCHING...'}e.innerHTML=r,document.body.appendChild(e),o>0&&setTimeout(s,o)}function E(){s();const n=document.createElement("div");n.id="sentinel-voice-hud",n.innerHTML=`
    <span>⚠️</span>
    SENTINEL_ACCESS_DENIED: MIC PERMISSION REQUIRED
  `,document.body.appendChild(n),setTimeout(s,15e3)}function s(){const n=document.getElementById("sentinel-voice-hud");n&&n.remove();const t=document.getElementById("sentinel-pinned-orb");t&&t.classList.remove("sentinel-listening")}h();console.log("[Sentinel_AI] Platform-Aware Extraction Engine (V3) initialized.");
